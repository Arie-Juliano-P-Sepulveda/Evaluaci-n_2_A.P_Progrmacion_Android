package cl.santos.evaluacion_2_arie_p_sepulveda;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity2 extends AppCompatActivity {
    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Intent intent = getIntent();
        String direccion1 = intent.getStringExtra("direccion1");
        String direccion2 = intent.getStringExtra("direccion2");
        String direccion3 = intent.getStringExtra("direccion3");

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.Map);
        mapFragment.getMapAsync(googleMap -> {
            mMap = googleMap;

            agregarMarcador(direccion1);
            agregarMarcador(direccion2);
            agregarMarcador(direccion3);
        });
    }

    private void agregarMarcador(String direccion) {
    }
}